// The anon key is designed to be public. Row Level Security (supabase/schema.sql) protects the data.
const SUPABASE_URL = 'https://YOUR-PROJECT.supabase.co';
const SUPABASE_ANON_KEY = 'YOUR-ANON-KEY';
