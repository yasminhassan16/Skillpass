create table profiles(id uuid primary key references auth.users on delete cascade, full_name text not null, role text not null default 'newcomer' check (role in ('newcomer','employer','assessor')), created_at timestamptz default now());
create table documents(id uuid primary key default gen_random_uuid(), user_id uuid not null references profiles on delete cascade, qualification text not null, institution text, country text, grad_year int, field text, file_path text not null, file_name text, status text not null default 'pending_review' check (status in ('pending_review','info_requested','verified','rejected')), assessor_note text, decided_by uuid references profiles, created_at timestamptz default now());
create table assessments(user_id uuid references profiles on delete cascade, track text, score int not null, total int not null, primary key(user_id,track));
create table passports(user_id uuid primary key references profiles on delete cascade, experience text default '', shared boolean not null default false);

create function my_role() returns text language sql stable security definer set search_path=public as $$ select role from profiles where id=auth.uid() $$;
create function is_shared(uid uuid) returns boolean language sql stable security definer set search_path=public as $$ select coalesce((select shared from passports where user_id=uid),false) $$;

-- Only newcomer or employer can be chosen at sign-up. Assessors are promoted by an administrator.
create function handle_new_user() returns trigger language plpgsql security definer set search_path=public as $$
begin insert into profiles(id,full_name,role) values(new.id,coalesce(new.raw_user_meta_data->>'full_name','New user'),case when new.raw_user_meta_data->>'role'='employer' then 'employer' else 'newcomer' end); return new; end $$;
create trigger on_auth_user_created after insert on auth.users for each row execute function handle_new_user();

alter table profiles enable row level security; alter table documents enable row level security;
alter table assessments enable row level security; alter table passports enable row level security;

create policy p_sel on profiles for select using (id=auth.uid() or my_role()='assessor' or (my_role()='employer' and is_shared(id)));
create policy d_sel on documents for select using (user_id=auth.uid() or my_role()='assessor' or (my_role()='employer' and is_shared(user_id)));
create policy d_ins on documents for insert with check (user_id=auth.uid() and status='pending_review');
create policy d_upd on documents for update using (my_role()='assessor') with check (my_role()='assessor');
create policy a_sel on assessments for select using (user_id=auth.uid() or my_role()='assessor' or (my_role()='employer' and is_shared(user_id)));
create policy a_ins on assessments for insert with check (user_id=auth.uid());
create policy a_upd on assessments for update using (user_id=auth.uid()) with check (user_id=auth.uid());
create policy s_sel on passports for select using (user_id=auth.uid() or my_role()='assessor' or (my_role()='employer' and shared));
create policy s_ins on passports for insert with check (user_id=auth.uid());
create policy s_upd on passports for update using (user_id=auth.uid()) with check (user_id=auth.uid());

-- Private document storage: owners and assessors only. Employers never get files.
insert into storage.buckets(id,name,public) values('credentials','credentials',false);
create policy f_ins on storage.objects for insert with check (bucket_id='credentials' and (storage.foldername(name))[1]=auth.uid()::text);
create policy f_sel on storage.objects for select using (bucket_id='credentials' and ((storage.foldername(name))[1]=auth.uid()::text or my_role()='assessor'));
