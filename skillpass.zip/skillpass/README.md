# SkillPass (stage 2: Supabase backend)

1. Create a Supabase project. In the SQL editor, run `supabase/schema.sql`.
2. In Auth settings, keep email confirmation on (users confirm by email, then log in).
3. Put your project URL and anon key in `public/config.js`.
4. Push to GitHub and import the repo in Netlify (settings come from `netlify.toml`).
5. Set Netlify environment variables: `SUPABASE_URL`, `SUPABASE_ANON_KEY`, `ANTHROPIC_API_KEY` (optional `ANTHROPIC_MODEL`).
6. Make an assessor: sign up normally, then run `update profiles set role='assessor' where id='<user id>';`

## Known gaps
- Quiz scores are calculated in the browser, so they are self-reported. Move scoring to a function next.
- The assessor review screen is not built yet. Until then, decisions need the Supabase table editor.
- Untested against a live Supabase project: run through register, upload, quiz, share and employer search after setup.
